
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'ashleydai96',
  applicationName: 'memes-app',
  appUid: 'MKNnjPwxK1CLQXhMHs',
  orgUid: '971575a2-5549-4564-9e25-5acaa053860d',
  deploymentUid: '97a5330f-415e-4a33-b550-73952d27f770',
  serviceName: 'memes',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'memes-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}